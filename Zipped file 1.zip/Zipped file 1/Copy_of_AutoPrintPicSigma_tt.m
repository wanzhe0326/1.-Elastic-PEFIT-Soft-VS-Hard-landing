

for ii=1:2:400
              
      file=[num2str(ii),'-Noncrack.mat'];
      
      load(file)
      
     figure ('Visible','Off')

 ttt=ii*5E02*1E-07; 

       Z=zeros(nz,nr);
for j=1:1:nz
    for i=1:1:nr
       Z(j,i)=NCp(i,j);
    end 
end
colormap('hot')
imagesc(Z)
set(gca, 'XTick', [200:200:4000]);
set(gca,'XTickLabel',{20:20:400});
set(gca, 'YTick', [50:50:450]);
set(gca,'YTickLabel',{5:5:45});
title( ['pore pressure',' (','t=', num2str(ttt),')'])
 colorbar
   caxis([-0.5 0.5])
%------------------------------------
%------------------------------------

print -dpng
          
                 
end





   
