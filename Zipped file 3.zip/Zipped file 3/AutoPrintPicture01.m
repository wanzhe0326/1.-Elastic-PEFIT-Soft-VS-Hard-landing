

dy=0.5;   % y range 0-10 m
dx=0.5;

nx=fix(820/dx);   % space x step

ny=fix(49/dy+1);   % space y step


for ii=1:2:400
              
      file=[num2str(ii),'-Noncrack.mat'];
      
      load(file)
      
%      tttt=ii*500*10^(-6);
%  
    figure ('Visible','Off')

%-----car-car-car-car--------------   
ax1 = subplot(1,1,1);
       Z=zeros(ny,nx);
for j=1:1:ny
    for i=1:1:nx
       Z(j,i)=NCp(i,j);
    end 
end
colormap('hot')
imagesc(Z)
 set(gca, 'XTick', [200:200:1600]);
 set(gca,'XTickLabel',{100:100:800});
 set(gca, 'YTick', [10:10:90]);
 set(gca,'YTickLabel',{5:5:45});
 colorbar
  caxis([-2 2])
%     
  print -dpng
       
end





   
