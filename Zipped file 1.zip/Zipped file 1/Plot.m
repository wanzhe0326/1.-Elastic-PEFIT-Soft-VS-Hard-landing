i=1;

switch(i)
    
    case 1
x1=10E-04:10E-04:0.4;
x2=10E-04:10E-04:0.5;
 plot(x1,result11(1,1:400),'r','LineWidth',1.5);
 hold on
 plot(x2,result1(1,1:500),'k','LineWidth',1.5);
 xlabel('Time (s)') 
 ylabel('Vertical stress (psi)') 
legend({'hard landing','soft landing'})


    case 2
x=5E-04:5E-04:0.4;
plot(x,result4,'r','LineWidth',1.5);
% hold on
% plot(x,result5,'k','LineWidth',1.5);
xlabel('Time (s)') 
ylabel('Pore pressure (psi)') 
legend({'Point 1','Point 2'})

end

ax = gca;
ax.FontSize = 15;

