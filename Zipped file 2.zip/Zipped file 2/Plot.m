i=1;

switch(i)
    
    case 1
 x=-200:1:199;
plot(x,Result44(1,1:400),'r','LineWidth',1.5);
hold on
plot(x,A(1,1:400),'k','LineWidth',1.5);
xlabel('Time (s)') 
ylabel('Vertical stress (psi)') 
 legend({'difference 01','difference 02'})
% legend({'Friction','Frictionless'})

    case 2
x=5E-04:5E-04:0.4;
plot(x,result4,'r','LineWidth',1.5);
% hold on
% plot(x,result5,'k','LineWidth',1.5);
xlabel('Time (s)') 
ylabel('Pore pressure (psi)') 
legend({'Point 1','Point 2'})

end

ax = gca;
ax.FontSize = 15;

% A(1,:)=B(1,:)