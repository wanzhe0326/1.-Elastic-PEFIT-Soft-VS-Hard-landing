i=1;

switch(i)
    
    case 1
 x=-200:1:199;
plot(x,result1,'r','LineWidth',1.5);
% hold on
% plot(x,result2,'k','LineWidth',1.5);
xlabel('Time (s)') 
ylabel('Vertical stress (psi)') 
legend({'Moving Load','Point 2'})


    case 2
x=5E-04:5E-04:0.4;
plot(x,result4,'r','LineWidth',1.5);
% hold on
% plot(x,result5,'k','LineWidth',1.5);
xlabel('Time (s)') 
ylabel('Pore pressure (psi)') 
legend({'Point 1','Point 2'})

end

ax = gca;
ax.FontSize = 15;

