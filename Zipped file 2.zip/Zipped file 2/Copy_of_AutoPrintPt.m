


% result1=zeros(1,800); % 501 is 500 number 1 zero initial value
% result2=zeros(1,800);
% result3=zeros(1,800); % 501 is 500 number 1 zero initial value
% result4=zeros(1,800);
% result5=zeros(1,800); % 501 is 500 number 1 zero initial value
% result6=zeros(1,800);


% jj=100;
% for ii=101:1:900
%               
%       file=[num2str(ii),'-Noncrack.mat'];
%       
%       load(file)
% 
%      
%       result1(1,ii-jj)=sigma_yy(841,8);
%       result2(1,ii-jj)=sigma_yy(841,13);
%       result3(1,ii-jj)=sigma_yy(841,19);
%       result4(1,ii-jj)=p(841,8);
%       result5(1,ii-jj)=p(841,13);
%       result6(1,ii-jj)=p(841,19);
% 
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 jj=100;
for ii=1:1:500
              
      file=[num2str(ii),'-Noncrack.mat'];
      
      load(file)
   
      result1(1,ii-jj)=sigma_yy(1240,8);
      result2(1,ii-jj)=sigma_yy(1240,13);
      result3(1,ii-jj)=sigma_yy(1240,19);


end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% for ii=101:1:500
%               
%       file=[num2str(ii),'-Noncrack.mat'];
%       
%       load(file)
% 
% for jj=0:1:399   
%     
%       result11(jj+1,ii+jj-100)=sigma_yy(1240-2*jj,8);
%       result22(jj+1,ii+jj-100)=sigma_yy(1240-2*jj,13);
%       result33(jj+1,ii+jj-100)=sigma_yy(1240-2*jj,19);
%       
% end
%  
% end
% 
% Result11=sum(result11);
% Result22=sum(result22);
% Result33=sum(result33);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% for ii=101:1:500
% %       for calculating matrix differences              
% %       file=[num2str(ii),'-Noncrack.mat'];
% %       
% %       load(file)
% % 
% %       A{ii-100} = sigma_yy;
% 
%       file=[num2str(ii),'-Noncrack.mat'];
%       load(file)
%       
%       result11(1,ii)=sigma_yy(1040,8);
%       result22(1,ii)=sigma_yy(1040,13);
%       result33(1,ii)=sigma_yy(1040,19);
%       
%       result44(1,ii)=sigma_yy(1240,8);
%       result55(1,ii)=sigma_yy(1240,13);
%       result66(1,ii)=sigma_yy(1240,19);
% 
%  
% end
