

for ii=1:1:700 
    
      file=[num2str(ii),'-Noncrack.mat'];
      load(file)
    
for jj=0:1:399
             
          result1(jj+1,ii+jj)=NCp(400-jj,7);
end

for jj=400:1:699
             
          result1(jj+1,ii+jj)=NCp(jj-399,7);
end




for kk=0:1:299
             
          result2(kk+1,ii+kk)=NCp(300-kk,7);
end

for kk=300:1:699
             
          result2(kk+1,ii+kk)=NCp(kk-299,7);
end




end

Result1=sum(result1);
Result2=sum(result2);
