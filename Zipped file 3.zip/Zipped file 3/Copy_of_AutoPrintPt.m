


% result1=zeros(1,800); % 501 is 500 number 1 zero initial value
% result2=zeros(1,800);
% result3=zeros(1,800); % 501 is 500 number 1 zero initial value
% result4=zeros(1,800);
% result5=zeros(1,800); % 501 is 500 number 1 zero initial value
% result6=zeros(1,800);


% res=zeros(1,500);
% 6m equal to 
% jj=100;
% for ii=101:1:900
%               
%       file=[num2str(ii),'-Noncrack.mat'];
%       
%       load(file)
% 
%      
%       result1(1,ii-jj)=sigma_yy(841,8);
%       result2(1,ii-jj)=sigma_yy(841,13);
%       result3(1,ii-jj)=sigma_yy(841,19);
%       result4(1,ii-jj)=p(841,8);
%       result5(1,ii-jj)=p(841,13);
%       result6(1,ii-jj)=p(841,19);
% 
% end
for ii=1:1:400
              
      file=[num2str(ii),'-Noncrack.mat'];
      
      load(file)
   
      result1(1,ii)=sigma_yy(840,8);
      result2(1,ii)=sigma_yy(840,13);
      result3(1,ii)=sigma_yy(840,19);


end