
% RUN prolonged moving point case first and then run this normal case


% res=zeros(1,500);
% 6m equal to 

% for ii=1:1:400
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%      
%       file=[num2str(ii),'-Noncrack.mat'];
%       
%       load(file)
% 
% %       for calculating matrix differences      
%        B{ii} = sigma_yy;
% %       
% % for jj=0:1:399   
% %     
% %       result1(jj+1,ii+jj)=sigma_yy(1240-2*jj,8);
% %       result2(jj+1,ii+jj)=sigma_yy(1240-2*jj,13);
% %       result3(jj+1,ii+jj)=sigma_yy(1240-2*jj,19);
% %       result4(jj+1,ii+jj)=sigma_yy(1240-2*jj,19);
% % end
%  
% end

%  result1(1,:)=result1(1,:);
%  result2(1,:)=result2(1,:);
%  result3(1,:)=result3(1,:);
% %  result4(1,:)=result33(1,:);
% %  
% Result1=sum(result1);
% Result2=sum(result2);
% Result3=sum(result3);
% Result4=sum(result4);


for ii=1:1:400
              
      file=[num2str(ii),'-Noncrack.mat'];
      
      load(file)
   
      result11(1,ii)=sigma_yy(840,1);
      result22(1,ii)=sigma_yy(1240,13);
      result33(1,ii)=sigma_yy(1240,19);


end

     
    